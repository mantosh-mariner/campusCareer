package bbsbec.online.exam.portal.repository;


import bbsbec.online.exam.portal.model.Login;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface AdminRepository extends JpaRepository<Login, String> {

//    @Query(name = "SELECT * FROM admin where username=: username AND password=:password", nativeQuery = true)
//    Admin findByIds(String username, String password);

    Login findByUsernameAndPassword(String username, String password);
}
