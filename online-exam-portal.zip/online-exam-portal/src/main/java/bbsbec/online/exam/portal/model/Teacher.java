package bbsbec.online.exam.portal.model;

import jakarta.persistence.*;
import org.apache.commons.lang3.RandomStringUtils;

@Entity
@Table(name = "teachers", uniqueConstraints = @UniqueConstraint(columnNames = "email"))
public class Teacher {

    @Id

    private String teacherId;

    private String name;

    @Column(unique = true, nullable = false)
    private String email;

    private String contact;
    private String address;
    private  String department;
    private  String status;


    // Getters and Setters

    public Teacher() {
        this.teacherId = "TECH" + RandomStringUtils.randomNumeric(6);
    }


    public String getTeacherId() {
        return teacherId;
    }

    public void setTeacherId(String teacherId) {
        this.teacherId = teacherId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getContact() {
        return contact;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status ="Active";
    }
}
