package bbsbec.online.exam.portal.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import org.apache.commons.lang3.RandomStringUtils;

@Entity
public class Student {

    @Id
    private String studentId;

    private String name;
    private String uniRoll;
    private String emailId;
    private String course;
    private String dob;
    private String branch;
    private String contact;
    private String session;
    private  String collegeRoll;
    private String status;

    // Constructor
    public Student() {
        this.studentId = "ST" + RandomStringUtils.randomNumeric(6);
    }

    // Getters and Setters

    public String getStudentId() {
        return studentId;
    }

    public void setStudentId(String studentId) {
        this.studentId = studentId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getUniRoll() {
        return uniRoll;
    }

    public void setUniRoll(String uniRoll) {
        this.uniRoll = uniRoll;
    }

    public String getCollegeRoll() {
        return collegeRoll;
    }

    public void setCollegeRoll(String collegeRoll) {
        this.collegeRoll = collegeRoll;
    }

    public String getEmailId() {
        return emailId;
    }

    public void setEmailId(String emailId) {
        this.emailId = emailId;
    }

    public String getCourse() {
        return course;
    }

    public void setCourse(String course) {
        this.course = course;
    }

    public String getDob() {
        return dob;
    }

    public void setDob(String dob) {
        this.dob = dob;
    }

    public String getBranch() {
        return branch;
    }

    public void setBranch(String branch) {
        this.branch = branch;
    }

    public String getContact() {
        return contact;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }

    public String getSession() {
        return session;
    }

    public void setSession(String session) {
        this.session = session;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status ="1";
    }
}
