package bbsbec.online.exam.portal.controller;

import bbsbec.online.exam.portal.model.Login;
import bbsbec.online.exam.portal.model.Student;
import bbsbec.online.exam.portal.service.AdminService;
import bbsbec.online.exam.portal.service.StudentService;
import bbsbec.online.exam.portal.service.TeacherService;
import org.apache.commons.lang3.RandomStringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Collections;
import java.util.List;

@RestController
@CrossOrigin("*")
public class StudentController {
    @Autowired
    private StudentService studentService;

    @Autowired
    private TeacherService teacherService;
    @Autowired
    private AdminService adminService;
    
    @PostMapping("/studentRegister")
    public ResponseEntity<?>register(@RequestBody Student student)
    {
        try {
            Student st=studentService.registerStudent(student);
            String pass= RandomStringUtils.random(6, true, true);
            Login logs=new Login();
            logs.setUsername(student.getEmailId());
            logs.setPassword(pass);
            logs.setRole("STUDENT");
            adminService.addlogin(logs);
           return ResponseEntity.ok(st);
        }catch (Exception e){
            System.out.println(e.getMessage());

           return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid credentials"+e.getMessage());
        }
        
    }

    @GetMapping("/Allstudent")
    public ResponseEntity<List<Student>> allStudent()
    {
        List<Student> allstudent=studentService.getAllstudent();

        if(!allstudent.isEmpty()){
            return ResponseEntity.ok(allstudent);
        }

        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(Collections.emptyList());
    }

    @PostMapping("/editStudent")
    public ResponseEntity<?> editStudent(@RequestBody Student student) {
        try {
//            System.out.println("sjd"+student.getStudentId()+" "+student.getBranch());
            Student updatedStudent = studentService.updateStudent(student);
            return ResponseEntity.ok(updatedStudent);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                    .body("Invalid credentials: " + e.getMessage());
        }
    }

}
