package bbsbec.online.exam.portal.service;


import bbsbec.online.exam.portal.model.Question;
import bbsbec.online.exam.portal.repository.QuestionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class QuestionService {

    @Autowired
    private QuestionRepository questionRepository;



    public Question addQuestion(Question question) {
        return questionRepository.save(question);
    }

    public List<Question> getallquestion(String examId) {
        return questionRepository.getallquestion(examId);
    }

    public void deleteQuestion(Long questionId) {
        questionRepository.deleteById(questionId);
    }
}
