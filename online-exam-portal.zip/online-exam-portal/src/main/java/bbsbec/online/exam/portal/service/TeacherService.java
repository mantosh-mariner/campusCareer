package bbsbec.online.exam.portal.service;

import bbsbec.online.exam.portal.model.Student;
import bbsbec.online.exam.portal.model.Teacher;
import bbsbec.online.exam.portal.repository.TeacherRepository;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TeacherService {

    @Autowired
    private TeacherRepository teacherRepository;
    public Teacher registerTeacher(Teacher teacher) {
        return teacherRepository.save(teacher);
    }

    public String getIds(String email) {
        System.out.println(email);
        return teacherRepository.findByemail(email);
    }

    public List<Teacher> getAllteacher() {
        return teacherRepository.findAll();
    }


    @Transactional
    public void deleteById(String teacherId) {
        teacherRepository.updateStatus(teacherId, "Dactive");
    }

    public Teacher updateTeacher(Teacher teacher) {
        int updatedRows = teacherRepository.updateTeacher(
                teacher.getTeacherId(), teacher.getEmail(), teacher.getName(), teacher.getContact(), teacher.getDepartment(), teacher.getStatus(), teacher.getAddress()
        );

        if (updatedRows > 0) {
            return teacher;
        } else {
            throw new RuntimeException("Update failed! Student not found.");
        }

    }
}
