package bbsbec.online.exam.portal.service;

import bbsbec.online.exam.portal.model.Teacher;
import bbsbec.online.exam.portal.repository.TeacherRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class TeacherService {

    @Autowired
    private TeacherRepository teacherRepository;
    public Teacher registerTeacher(Teacher teacher) {
        return teacherRepository.save(teacher);
    }

    public String getIds(String email) {
        System.out.println(email);
        return teacherRepository.findByemail(email);
    }
}
