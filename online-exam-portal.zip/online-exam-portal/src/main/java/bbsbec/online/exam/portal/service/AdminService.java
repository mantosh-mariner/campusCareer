package bbsbec.online.exam.portal.service;

//import bbsbec.online.exam.portal.model.Admin;
import bbsbec.online.exam.portal.model.Login;
import bbsbec.online.exam.portal.repository.AdminRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AdminService {

    @Autowired
    private AdminRepository adminRepository;

    public Login adminLogin(String username, String password) {
        return adminRepository.findByUsernameAndPassword(username, password);
    }

    public void addlogin(Login logs) {
        adminRepository.save(logs);
    }
}
