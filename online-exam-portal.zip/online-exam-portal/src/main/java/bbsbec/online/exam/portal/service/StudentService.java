package bbsbec.online.exam.portal.service;


import bbsbec.online.exam.portal.model.Student;
import bbsbec.online.exam.portal.repository.StudentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class StudentService {

    @Autowired
    private StudentRepository studentRepository;
    public Student registerStudent(Student student) {
        return studentRepository.save((student));
    }

    public List<Student> getAllstudent() {
        return studentRepository.findAll();
    }



    public Student updateStudent(Student student) {
        int updatedRows = studentRepository.updateStudent(
                student.getStudentId(), student.getName(), student.getBranch(),
                student.getDob(), student.getContact(), student.getEmailId(),
                student.getSession(), student.getUniRoll(), student.getCollegeRoll(), student.getCourse()
        );

        if (updatedRows > 0) {
            return student;  // Return the updated student object
        } else {
            throw new RuntimeException("Update failed! Student not found.");
        }
    }


}
