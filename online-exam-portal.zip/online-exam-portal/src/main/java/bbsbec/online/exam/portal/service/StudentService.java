package bbsbec.online.exam.portal.service;


import bbsbec.online.exam.portal.model.Student;
import bbsbec.online.exam.portal.repository.StudentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class StudentService {

    @Autowired
    private StudentRepository studentRepository;
    public Student registerStudent(Student student) {
        return studentRepository.save((student));
    }
}
