package bbsbec.online.exam.portal.controller;


import bbsbec.online.exam.portal.model.Login;
import bbsbec.online.exam.portal.model.Student;
import bbsbec.online.exam.portal.model.Teacher;
import bbsbec.online.exam.portal.service.AdminService;
import bbsbec.online.exam.portal.service.TeacherService;
import org.apache.commons.lang3.RandomStringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Collections;
import java.util.List;

@RestController
@CrossOrigin("*")
public class TeacherController {

    private static final Logger log = LoggerFactory.getLogger(TeacherController.class);
    @Autowired
    private TeacherService teacherService;
    @Autowired
    private AdminService adminService;

    @PostMapping("/addTeacher")
    public ResponseEntity<?> addteacher(@RequestBody Teacher teacher)
    {
        teacher.setStatus("Active");
        Teacher reg=teacherService.registerTeacher(teacher);
        Login logs=new Login();
        String pass= RandomStringUtils.random(6, true, true);
        logs.setUsername(teacher.getEmail());
        logs.setPassword(pass);
        logs.setRole("TEACHER");

        adminService.addlogin(logs);
        return ResponseEntity.ok(reg);
    }
    @GetMapping("/id")
    public ResponseEntity<?> getId(@RequestParam String username) {
        System.out.println(username);
        String teacherId = teacherService.getIds(username);

        if (teacherId != null) {
            return ResponseEntity.ok(teacherId);
        }
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Invalid email or teacher not found");
    }

    @GetMapping("/AllTeacher")
    public ResponseEntity<List<Teacher>> allteacher()
    {
        List<Teacher> allstudent=teacherService.getAllteacher();

        if(!allstudent.isEmpty()){
            return ResponseEntity.ok(allstudent);
        }

        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(Collections.emptyList());
    }

    @PostMapping("/editTeacher")
    public ResponseEntity<?> editTeacher(@RequestBody Teacher teacher) {
        try {
//            System.out.println("sjd"+student.getStudentId()+" "+student.getBranch());
            Teacher updateteacher = teacherService.updateTeacher(teacher);
            return ResponseEntity.ok(updateteacher);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                    .body("Invalid credentials: " + e.getMessage());
        }
    }

    @PostMapping("/deleteTeacher")
    public ResponseEntity<?> deleteTeacher(@RequestParam String teacherId) {
        try {
            teacherService.deleteById(teacherId);
            return ResponseEntity.ok("Teacher deactivated successfully.");
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Error while deactivating teacher: " + e.getMessage());
        }
    }

}
