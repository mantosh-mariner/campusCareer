package bbsbec.online.exam.portal.controller;


import bbsbec.online.exam.portal.model.Login;
import bbsbec.online.exam.portal.model.Teacher;
import bbsbec.online.exam.portal.service.AdminService;
import bbsbec.online.exam.portal.service.TeacherService;
import org.apache.commons.lang3.RandomStringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@CrossOrigin("*")
public class TeacherController {

    @Autowired
    private TeacherService teacherService;
    @Autowired
    private AdminService adminService;

    @PostMapping("/addTeacher")
    public ResponseEntity<?> addteacher(@RequestBody Teacher teacher)
    {
        Teacher reg=teacherService.registerTeacher(teacher);
        Login logs=new Login();
        String pass= RandomStringUtils.random(6, true, true);
        logs.setUsername(teacher.getEmail());
        logs.setPassword(pass);
        logs.setRole("TEACHER");
        adminService.addlogin(logs);
        return ResponseEntity.ok(reg);
    }
    @GetMapping("/id")
    public ResponseEntity<?> getId(@RequestParam String username) {
        System.out.println(username);
        String teacherId = teacherService.getIds(username);

        if (teacherId != null) {
            return ResponseEntity.ok(teacherId);
        }
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Invalid email or teacher not found");
    }




}
