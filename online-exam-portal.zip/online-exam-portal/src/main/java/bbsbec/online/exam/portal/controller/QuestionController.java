package bbsbec.online.exam.portal.controller;


import bbsbec.online.exam.portal.model.Exam;
import bbsbec.online.exam.portal.model.Question;
import bbsbec.online.exam.portal.service.QuestionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.*;
import java.util.stream.Collectors;

@RestController
@CrossOrigin("*")
public class QuestionController {

    @Autowired
    private QuestionService questionService;

    @PostMapping("/addQuestion")
    public ResponseEntity<Map<String, String>> addQuestion(
            @RequestParam("questionName") String questionName,
            @RequestParam("optionA") String optionA,
            @RequestParam("optionB") String optionB,
            @RequestParam("optionC") String optionC,
            @RequestParam("optionD") String optionD,
            @RequestParam("optionE") String optionE,
            @RequestParam("correctOption") String correctOption,
            @RequestParam("marks") String marks,
            @RequestParam("examId") String examId,
            @RequestParam(value = "photo", required = false) MultipartFile photo
    ) {
        System.out.println(examId);
        try {
            Question question = new Question();
            question.setQuestionName(questionName);
            question.setOptionA(optionA);
            question.setOptionB(optionB);
            question.setOptionC(optionC);
            question.setOptionD(optionD);
            question.setOptionE(optionE);
            question.setCurrectOption(correctOption);
            question.setMarks(marks);

            // Set Exam object
            Exam exam = new Exam();
            exam.setExamId(examId);
            question.setExam(exam);

            // Set Photo (if provided)
            if (photo != null && !photo.isEmpty()) {
                question.setPhoto(photo.getBytes()); // Convert image to byte array
            }

            questionService.addQuestion(question);

            Map<String, String> response = new HashMap<>();
            response.put("message", "Question added successfully");
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            Map<String, String> errorResponse = new HashMap<>();
            errorResponse.put("error", "Error saving question: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(errorResponse);
        }
    }

    @GetMapping("/allquestions")
    public ResponseEntity<List<Map<String, Object>>> allquestion(@RequestParam String examId) {
        List<Question> questions = questionService.getallquestion(examId);

        try {
            List<Map<String, Object>> formattedQuestions = questions.stream().map(q -> {
                Map<String, Object> questionMap = new HashMap<>();
                questionMap.put("questionId", q.getQuestionId());
                questionMap.put("questionName", q.getQuestionName());
                questionMap.put("optionA", q.getOptionA());
                questionMap.put("optionB", q.getOptionB());
                questionMap.put("optionC", q.getOptionC());
                questionMap.put("optionD", q.getOptionD());
                questionMap.put("optionE", q.getOptionE());
                questionMap.put("marks", q.getMarks());
                questionMap.put("correctOption", q.getCurrectOption());


                if (q.getPhoto() != null) {
                    String base64Photo = Base64.getEncoder().encodeToString(q.getPhoto());
                    questionMap.put("photo", base64Photo);
                } else {
                    questionMap.put("photo", null);
                }

                return questionMap;
            }).collect(Collectors.toList());

            return ResponseEntity.ok(formattedQuestions);
        }
        catch (Exception e) {

            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(Collections.emptyList());
        }
    }
}