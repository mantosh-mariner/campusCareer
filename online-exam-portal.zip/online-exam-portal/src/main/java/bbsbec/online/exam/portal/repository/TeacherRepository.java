package bbsbec.online.exam.portal.repository;

import bbsbec.online.exam.portal.model.Teacher;
import jakarta.transaction.Transactional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface TeacherRepository extends JpaRepository<Teacher, String> {

    @Query(value = "SELECT teacherId FROM teachers WHERE email = :email AND status = 'Active'", nativeQuery = true)
    String findByemail(String email);

    @Transactional
    @Modifying
    @Query(value = "UPDATE teachers SET status = :status WHERE teacherId = :teacherId", nativeQuery = true)
    void updateStatus(String teacherId, String status);

    @Transactional
    @Modifying
    @Query(value = "UPDATE teachers SET email = :email, name = :name, contact = :contact, department = :department, status = :status, address = :address WHERE teacherId = :teacherId", nativeQuery = true)
    int updateTeacher(String teacherId, String email, String name, String contact, String department, String status, String address);
}
