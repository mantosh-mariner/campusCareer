
package bbsbec.online.exam.portal.service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import bbsbec.online.exam.portal.model.Exam;
import bbsbec.online.exam.portal.model.Teacher;
import bbsbec.online.exam.portal.repository.ExamRepository;
import bbsbec.online.exam.portal.repository.TeacherRepository;

import java.util.List;
import java.util.Optional;

@Service
public class ExamService {
    @Autowired
    private ExamRepository examRepository;

    @Autowired
    private TeacherRepository teacherRepository;

    public Exam addExams(Exam exam) {
        if (exam.getTeacher() == null) {
            throw new RuntimeException("Teacher object is null");
        }

        if (exam.getTeacher().getTeacherId() == null) {
            throw new RuntimeException("Teacher ID is required but found null");
        }

        System.out.println("Received Teacher ID: " + exam.getTeacher().getTeacherId());

        Optional<Teacher> teacherOpt = teacherRepository.findById(exam.getTeacher().getTeacherId());
        if (teacherOpt.isPresent()) {
            exam.setTeacher(teacherOpt.get()); // Set the existing Teacher object
            return examRepository.save(exam);
        } else {
            throw new RuntimeException("Invalid Teacher ID: " + exam.getTeacher().getTeacherId());
        }
    }

    public String getExamId(String getexamid) {
        return examRepository.findByIds(getexamid);
    }

    public List<List<Object>> getallexam(String teacherId) {
        return examRepository.getallexamByteacherId(teacherId);
    }
}
