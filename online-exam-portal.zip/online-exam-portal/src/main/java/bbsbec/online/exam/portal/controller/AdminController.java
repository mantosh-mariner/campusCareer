package bbsbec.online.exam.portal.controller;

import bbsbec.online.exam.portal.model.Login;
import bbsbec.online.exam.portal.service.AdminService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
//@RequestMapping("/")
@CrossOrigin(origins = "*")

//@CrossOrigin(origins = "http://localhost:3000")  // Allow frontend requests
public class AdminController {

    @Autowired
    private AdminService adminService;

    @PostMapping("/adminlogin")
    public ResponseEntity<?> adminLogin(@RequestBody Login login) {
        System.out.println(login.getPassword()+" "+login.getUsername());
        Login log = adminService.adminLogin(login.getUsername(), login.getPassword());
        if (log != null) {
            return ResponseEntity.ok(log);
        }
        return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid credentials");
    }
}
