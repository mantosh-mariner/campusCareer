package bbsbec.online.exam.portal.repository;

import bbsbec.online.exam.portal.model.Student;
import jakarta.transaction.Transactional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface StudentRepository extends JpaRepository<Student, String> {


    @Modifying
    @Transactional
    @Query("UPDATE Student s SET s.name=:name, s.branch=:branch, s.dob=:dob, s.contact=:contact, " +
            "s.emailId=:emailId, s.session=:session, s.course=:course, s.uniRoll=:uniRoll, s.collegeRoll=:collegeRoll " +
            "WHERE s.studentId=:studentId")
    int updateStudent(String studentId, String name, String branch, String dob,
                      String contact, String emailId, String session,
                      String uniRoll, String collegeRoll, String course);

}
