package bbsbec.online.exam.portal.repository;


import bbsbec.online.exam.portal.model.Exam;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ExamRepository extends JpaRepository<Exam, String> {


    @Query(value = "SELECT examId FROM exam WHERE teacherId=:getexamid order by examDate asc limit 1", nativeQuery = true)
    String findByIds(String getexamid);

    @Query(value = "SELECT * FROM exam WHERE teacherId=:teacherId ", nativeQuery = true)
    List<List<Object>> getallexamByteacherId(String teacherId);
}
