package bbsbec.online.exam.portal.controller;

import bbsbec.online.exam.portal.model.Exam;
import bbsbec.online.exam.portal.service.ExamService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.Collections;
import java.util.List;

@RestController
@CrossOrigin("*")
public class ExamController {

    @Autowired
    private ExamService examService;

    @PostMapping("/addExam")
    public ResponseEntity<?> addExam(@RequestBody Exam exam) {
        try {
            Exam savedExam = examService.addExams(exam);
            if (savedExam != null) {
                return ResponseEntity.ok("Exam Added Successfully");
            } else {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Failed to add exam");
            }
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error: " + e.getMessage());
        }
    }


    @GetMapping("/add-exam")
    public ResponseEntity<?> getexamId(@RequestParam String teacherId) {
        System.out.println(teacherId);
        String examId = examService.getExamId(teacherId);

        if (examId != null) {
            return ResponseEntity.ok(examId);
        }
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Invalid email or teacher not found");
    }


    @GetMapping("/getallexam")
    public ResponseEntity<List<List<Object>>> getallexam(@RequestParam String teacherId) {
        System.out.println(teacherId);
        List<List<Object>>  ans= examService.getallexam(teacherId);

        if (ans != null && !ans.isEmpty()) {
            return ResponseEntity.ok(ans);
        }
        return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                .body(Collections.emptyList());
    }

}
